#!/bin/bashz
ext="sh"
ls -lx | grep ".$ext" > llistat.txt
    
echo "S'han guardat els arxius amb extensio .$ext al fitxer llistat.txt"