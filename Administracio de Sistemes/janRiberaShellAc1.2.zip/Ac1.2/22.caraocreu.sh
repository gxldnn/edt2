#!/bin/bash

read -n 1 -p "Escull un numero entre 1 o 2: " num
random=$(( $RANDOM % 2 + 1))

if [ $num -eq $random ];then
    echo -e "\nHas encertat!"
else
    echo -e "\nQuina pena"
fi


##### Versio "facil"

#read -n 1 -p "Escull un numero entre 1 o 2: " num
#random=$(( $RANDOM % 2 ))
#
#if [ $random -eq 0 ];then 
#    random=1
#else
#    random=2
#fi
#
#if [ $num -eq $random ];then
#    echo -e "\nHas encertat!"
#else
#    echo -e "\nQuina pena"
#fi

