#!/bin/bash
while true; do
    
    read -n 1 -p "Escull un numero entre 1 o 10: " num
    clear
    random=$(( $RANDOM % 10 + 1 ))

    if [ $num -eq $random ];then
        echo -e "\nHas encertat! es $random"
        break
    else
        echo -e "\nQuina pena era $random"
    fi
done